import React from 'react'

const UserProfile = () => {
  return (
    <div>
        <div className='div-left'>
              hello
        </div>
        <div className='div-right'>
        hrllo
        </div>
    </div>
  )
}

export default UserProfile